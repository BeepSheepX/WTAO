Weapon and tools: made by me,BeepSheepX.

Armor: made by pixel artist on the lnternet. Edit to Armor form by me.

Sorry can't find all the artist's name,here are everyone I can find:

Zowja,Birdy,Del Cottonwood,Nighthearted,stuffles,Mikkellaneous,Flawsaken,thatguyjake,legoskeleton,

Laurenangels__,shiva,Valerii Kim,pvddinq,Lrish,Ghostrle,Beverly,Icekreem,WAAH.